[ja]
<これは何？>
これはNinty Launcher用のカスタムテーマです。
Ninty LancherとはNinStar( https://ninstar.carrd.co/ )さんが開発したゲームランチャーソフトです。
ランチャーは https://ninstars.itch.io/ninty からダウンロードすることができます。
--------------------
<ファイル内容について>
・WiiU.png - 画像ファイルです。
・WiiU.ini - 設定ファイルです。カーソルの色などを指定しています。
・WiiU.ogg - 音声ファイルです。ランチャーを開いている間はこの音声が再生されます。
--------------------
<テーマ設定時の注意事項>
これらのカスタムテーマは画像ファイルとiniファイルとoggファイルがセットになっているので、
ファイルを別の場所に移動する際は、iniファイルとoggファイルも一緒に移動させてください。
コピーする際も、iniファイルとoggファイルを一緒にコピーしてください。
画像ファイル名を変更する際は、iniファイルもoggファイルも同じファイル名にしてください。


[en]
<What is this? >
This is a set of icons for Ninty Launcher.
Ninty Lancher is a game launcher software developed by NinStar ( https://ninstar.carrd.co/ ).
The launcher can be downloaded from https://ninstars.itch.io/ninty
--------------------
<About the file contents>
・WiiU.png - Image file.
・WiiU.ini - Configuration file. Specifies cursor color and other settings.
・WiiU.ogg - Audio file. Plays while the launcher is open.
--------------------
<Notes when setting up a theme>
These custom themes consist of a set of image files, ini files, and ogg files.
When moving files to another location, please move the ini files and ogg files together with them.
When copying files, please copy the ini files and ogg files together as well.
When changing an image file name, please ensure the ini file and ogg file also have the same file name.

--------------------
Made by koromoko10( https://lit.link/koromoko10 )