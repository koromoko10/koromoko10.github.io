[ja]
<これは何？>
これはNinty Launcher用のアイコンセットです。
Ninty LancherとはNinStar( https://ninstar.carrd.co/ )さんが開発したゲームランチャーソフトです。
ランチャーは https://ninstars.itch.io/ninty からダウンロードすることができます。
--------------------
<ファイル内容について>
・0840 Chat.png - 256x256ピクセルの通常アイコンです。
・0840 Chat_touka.png - 256x256ピクセルの背景が透過されたアイコンです。

[en]
<What is this? >
This is a set of icons for Ninty Launcher.
Ninty Lancher is a game launcher software developed by NinStar ( https://ninstar.carrd.co/ ).
The launcher can be downloaded from https://ninstars.itch.io/ninty
--------------------
<About the file contents>
・0840 Chat.png - Normal icon of 256x256 pixels.
・0840 Chat_touka.png - 256x256 pixel icon with transparent background.


--------------------
Made by koromoko10( https://lit.link/koromoko10 )
