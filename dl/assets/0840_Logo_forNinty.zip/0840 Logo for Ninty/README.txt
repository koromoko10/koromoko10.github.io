[ja]
<これは何？>
これはNinty Launcher用のアイコンセットです。
Ninty LancherとはNinStar( https://ninstar.carrd.co/ )さんが開発したゲームランチャーソフトです。
ランチャーは https://ninstars.itch.io/ninty からダウンロードすることができます。
--------------------
<ファイル内容について>
・0840 Chat.png - 256x256ピクセルの通常アイコンです。
・0840 Chat_touka.png - 256x256ピクセルの背景が透過されたアイコンです。
・0840 Chat_Motion_anim64_speed5.png - 256x256ピクセルの動くアイコンです。
・extra - 動くアイコンの副産物をまとめました。アイコンとして設定できません。
   ・0840 Chat_Motion.gif - 15fpsのGIF画像です。Figma Motionを使いました。
   ・0840 Chat_Motion.mp4 - 30fpsの動画ファイルです。
   ・0840 Chat_Motion.svg - SVGファイルです。

[en]
<What is this? >
This is a set of icons for Ninty Launcher.
Ninty Lancher is a game launcher software developed by NinStar ( https://ninstar.carrd.co/ ).
The launcher can be downloaded from https://ninstars.itch.io/ninty
--------------------
<About the file contents>
・0840 Chat.png - Normal icon of 256x256 pixels.
・0840 Chat_touka.png - 256x256 pixel icon with transparent background.
・0840 Chat_Motion_anim64_speed5.png - A 256x256-pixel animated icon.
・extra - I've compiled some byproducts of the animated icons. These cannot be set as icons.
   ・0840 Chat_Motion.gif - A 15 fps GIF image. Created using Figma Motion.
   ・0840 Chat_Motion.mp4 - A 30 fps video file.
   ・0840 Chat_Motion.svg - A SVG file.

--------------------
Made by koromoko10( https://lit.link/koromoko10 )
