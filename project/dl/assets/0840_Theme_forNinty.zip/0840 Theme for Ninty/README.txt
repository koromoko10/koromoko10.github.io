[ja]
<これは何？>
これはNinty Launcher用のカスタムテーマです。
Ninty LancherとはNinStar( https://ninstar.carrd.co/ )さんが開発したゲームランチャーソフトです。
ランチャーは https://ninstars.itch.io/ninty からダウンロードすることができます。
--------------------
<ファイル内容について>
・0840_title.png - 0840 Chatのタイトル画面で表示される背景画像をもとに作成しました。
・0840_title_dark.png - 0840 Chatのタイトル画面で表示される背景画像をダークモード化してみました。
・0840_TL.png - 0840 Chatのチャット画面（TL）で表示される背景画像をもとに作成しました。
・0840_title_dark.png - 0840 Chatのチャット画面（TL）で表示される背景画像をダークモード化してみました。
--------------------
<テーマ設定時の注意事項>
これらのカスタムテーマは画像ファイルとiniファイルがセットになっているので、
ファイルを別の場所に移動する際は、iniファイルも一緒に移動させてください。
コピーする際も、iniファイルを一緒にコピーしてください。
画像ファイル名を変更する際は、iniファイルも同じファイル名にしてください。


[en]
<What is this? >
This is a set of icons for Ninty Launcher.
Ninty Lancher is a game launcher software developed by NinStar ( https://ninstar.carrd.co/ ).
The launcher can be downloaded from https://ninstars.itch.io/ninty
--------------------
<About the file contents>
・0840_title.png - Based on the background image displayed on the title screen of 0840 Chat.
・0840_title_dark.png - Based on the background image displayed on the title screen of 0840 Chat in dark mode.
・0840_TL.png - Based on the background image displayed on the 0840 Chat chat screen (TL).
・0840_title_dark.png - Based on the background image displayed on the 0840 Chat chat screen (TL) in dark mode.
--------------------
<Notes when setting up a theme>
These custom themes are a set of image files and ini files,
When you move files to a different location, please move the ini files with them.
When copying, copy the ini files as well.
When renaming an image file, the ini file should also be renamed to the same file name.


--------------------
Made by koromoko10( https://lit.link/koromoko10 )